import os
import csv
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMessageBox
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsGraduatedSymbolRenderer,
    QgsRendererRange,
    QgsSymbol,
    QgsStyle
)

class SnifferPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None

    def initGui(self):
        self.action = QAction("Carica CSV Sniffer (Simbologia Graduata)", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        
        self.iface.addPluginToVectorMenu("Sniffer CSV Loader", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginVectorMenu("Sniffer CSV Loader", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        filename, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Seleziona il file CSV dello Sniffer",
            "",
            "CSV Files (*.csv *.CSV)"
        )
        
        if not filename:
            return

        target_columns = [
            "Temperature ℃",
            "Humidity %",
            "Pressure Pa",
            "PM1.0 μg/m³",
            "PM2.5 μg/m³",
            "PM10 μg/m³",
            "CxHy/Flammable Gases %",
            "CO2 mg/m³"
        ]

        try:
            with open(filename, mode='r', encoding='utf-8-sig', errors='ignore') as f:
                reader = csv.reader(f)
                rows = list(reader)
                
                header_row_index = -1
                headers = []
                for idx, row in enumerate(rows):
                    if "Longitude" in row and "Latitude" in row:
                        header_row_index = idx
                        headers = row
                        break
                
                if header_row_index == -1:
                    QMessageBox.warning(self.iface.mainWindow(), "Errore", "Impossibile trovare le colonne Longitude e Latitude nel file CSV.")
                    return

                try:
                    lon_idx = headers.index("Longitude")
                    lat_idx = headers.index("Latitude")
                    time_idx = headers.index("Time Stamp") if "Time Stamp" in headers else -1
                except ValueError as e:
                    QMessageBox.warning(self.iface.mainWindow(), "Errore", f"Colonna obbligatoria mancante: {e}")
                    return

                col_indices = {}
                for col in target_columns:
                    if col in headers:
                        col_indices[col] = headers.index(col)

                data_rows = rows[header_row_index + 1:]
                created_layers = 0

                for col_name, c_idx in col_indices.items():
                    layer_uri = "Point?crs=EPSG:4326&field=id:integer&field=timestamp:string&field=valore:double"
                    layer_name = f"Sniffer - {col_name}"
                    vector_layer = QgsVectorLayer(layer_uri, layer_name, "memory")
                    
                    if not vector_layer.isValid():
                        continue

                    dataProvider = vector_layer.dataProvider()
                    features = []
                    feat_id = 1
                    values = []

                    for r in data_rows:
                        if len(r) <= max(lon_idx, lat_idx, c_idx):
                            continue
                        
                        try:
                            lon = float(r[lon_idx])
                            lat = float(r[lat_idx])
                            val_str = r[c_idx].strip()
                            if not val_str:
                                continue
                            val = float(val_str)
                            
                            timestamp = r[time_idx] if time_idx != -1 and len(r) > time_idx else ""

                            feature = QgsFeature()
                            feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
                            feature.setAttributes([feat_id, timestamp, val])
                            features.append(feature)
                            values.append(val)
                            feat_id += 1
                        except ValueError:
                            continue

                    dataProvider.addFeatures(features)
                    vector_layer.updateExtents()

                    # Configurazione corretta della simbologia graduata
                    if values:
                        min_val = min(values)
                        max_val = max(values)
                        
                        if min_val == max_val:
                            max_val = min_val + 1.0

                        num_classes = 5
                        color_ramp = QgsStyle.defaultStyle().colorRamp('Spectral')
                        if color_ramp:
                            color_ramp.invert()
                            
                        ranges = []
                        step = (max_val - min_val) / num_classes
                        
                        for i in range(num_classes):
                            r_min = min_val + i * step
                            r_max = min_val + (i + 1) * step if i < num_classes - 1 else max_val
                            
                            color = color_ramp.color(i / max(1, num_classes - 1)) if color_ramp else QColor(100, 100, 100)
                            
                            symbol = QgsSymbol.defaultSymbol(vector_layer.geometryType())
                            symbol.setColor(color)
                            symbol.setSize(2.5)
                            
                            range_item = QgsRendererRange(r_min, r_max, symbol, f"{r_min:.2f} - {r_max:.2f}")
                            ranges.append(range_item)
                            
                        # Crea il renderer passando direttamente il campo e la lista dei range
                        renderer = QgsGraduatedSymbolRenderer('valore', ranges)
                        vector_layer.setRenderer(renderer)

                    QgsProject.instance().addMapLayer(vector_layer)
                    created_layers += 1

                QMessageBox.information(
                    self.iface.mainWindow(), 
                    "Completato", 
                    f"Caricamento completato con simbologia graduata! Creati {created_layers} layer."
                )

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Errore", f"Errore durante la lettura del file: {str(e)}")