def classFactory(iface):
    from .sniffer_plugin import SnifferPlugin
    return SnifferPlugin(iface)